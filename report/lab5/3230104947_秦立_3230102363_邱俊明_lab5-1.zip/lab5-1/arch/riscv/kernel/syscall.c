#include "syscall.h"

#include "task_manager.h"
#include "stdio.h"
#include "defs.h"
#include "slub.h"
#include "mm.h"


struct ret_info syscall(uint64_t syscall_num, uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5) {
    struct ret_info ret;
    switch (syscall_num) {
    case SYS_GETPID: {
        ret.a0 = getpid();
        break;
    }
    case SYS_WRITE: {
        int fd = arg0;
        char* buffer = (char*)arg1;
        int size = arg2;
        if(fd == 1) {
            for(int i = 0; i < size; i++) {
                putchar(buffer[i]);
            }
        }
        ret.a0 = size;
        break;
    }
    case SYS_MMAP: {
        // TODO: implement mmap
        // 1. create a new vma struct (kmalloc), if kmalloc failed, return -1
        struct vm_area_struct *vma = (struct vm_area_struct *)kmalloc(sizeof(struct vm_area_struct));
        if (vma == NULL) {
            ret.a0 = -1;
            break;
        }
        // 2. initialize the vma struct
        // 2.1 set the vm_start and vm_end according to arg0 and arg1
        vma->vm_start = arg0;
        vma->vm_end = arg0 + arg1;
        // 2.2 set the vm_flags to arg2
        vma->vm_flags = arg2;
        // 2.3 set the mapped flag to 0
        vma->mapped = 0;
        // 3. add the vma struct to the mm_struct's vma list
        list_add(&(vma->vm_list), &(current->mm.vm->vm_list));
        // return the vm_start
        ret.a0 = vma->vm_start;
        break;

    }
    case SYS_MUNMAP: {
        // TODO: implement munmap
        // 1. find the vma according to arg0 and arg1
        // note: you can iterate the vm_list by list_for_each_entry(vma, &current->mm.vm->vm_list, vm_list), then you can use `vma` in your loop
        struct vm_area_struct *vma;
        struct vm_area_struct *target_vma = NULL;
        list_for_each_entry(vma, &current->mm.vm->vm_list, vm_list) {
            if (vma->vm_start == arg0 && vma->vm_end == arg0 + arg1) {
                target_vma = vma;
                break;
            }
        }
        
        if (target_vma == NULL) {
            ret.a0 = -1;
            break;
        }

        // 2. if the vma mapped, free the physical pages (free_pages). Using `get_pte` to get the corresponding pte.
        // 3. ummap the physical pages from the virtual address space (create_mapping)
        if (target_vma->mapped) {
            uint64_t pgtbl = (current->satp & 0xFFFFFFFFFFF) << 12;
            for (uint64_t addr = target_vma->vm_start; addr < target_vma->vm_end; addr += PAGE_SIZE) {
                uint64_t pte = get_pte((uint64_t*)pgtbl, addr);
                if (pte & PTE_V) {
                    uint64_t pa = (pte >> 10) << 12;    // 根页表（Root Page Table）的物理页号
                    free_pages(pa);
                    create_mapping((uint64_t*)pgtbl, addr, 0, PAGE_SIZE, 0);
                }
            }
        }

        // 4. delete the vma from the mm_struct's vma list (list_del).
        list_del(&(target_vma->vm_list));
        // 5. free the vma struct (kfree).
        kfree(target_vma);
        // return 0 if success, otherwise return -1
        ret.a0 = 0;


        // flash the TLB
        asm volatile ("sfence.vma");
        break;


    }
    default:
        printf("Unknown syscall! syscall_num = %d\n", syscall_num);
        while(1);
        break;
    }
    return ret;
}