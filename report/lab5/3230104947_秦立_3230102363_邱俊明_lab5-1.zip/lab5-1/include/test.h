#pragma once

extern int ticks;
void init_test_case();