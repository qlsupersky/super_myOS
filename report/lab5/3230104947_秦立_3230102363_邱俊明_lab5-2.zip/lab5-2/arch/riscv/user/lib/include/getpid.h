#pragma once
#include "types.h"

uint64_t current_sp();

long getpid();
