#pragma once

int getchar();